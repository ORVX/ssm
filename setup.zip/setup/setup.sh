#!/bin/bash

# Arguments verification

while getopts ":d:domain:u:username:p:password:" opt; do
  case $opt in
    d|domain) domain="$OPTARG"
    ;;
    u|username) username="$OPTARG"
    ;;
    p|password) password="$OPTARG"
    ;;
    \?) echo "Invalid argument -$OPTARG." >&2
    ;;
  esac
done

if [ $# -eq 0 ]
then
    echo "Please provide -d -u -p arguments.\n./setup.sh -d domain.com -u username -p password"
    exit 1
fi

if [ -z "$domain" ];
then
    echo "Please provide '-d | --domain' argument.\n./setup.sh -d domain.com -u username -p password"
    exit 2
fi

if [ -z "$username" ];
then
    echo "Please provide '-u | --username' argument.\n./setup.sh -d domain.com -u username -p password"
    exit 3
fi

if [ -z "$password" ];
then
    echo "Please provide '-p | --password' argument.\n./setup.sh -d domain.com -u username -p password"
    exit 4
fi

# Open script directory

cd $(dirname $0)

# Update repos

apt-get update -y
DEBIAN_FRONTEND=noninteractive apt-get upgrade -y

# Firewall install

apt-get install ufw -y

# Firewall configuration

ufw default deny incoming
ufw default allow outgoing
ufw allow 22/tcp
ufw allow 25/tcp
ufw allow 80/tcp
ufw allow 443/tcp
ufw allow 587/tcp
ufw allow 465/tcp
ufw allow 143/tcp
ufw allow 993/tcp
ufw allow 110/tcp
ufw allow 995/tcp

yes | sudo ufw enable

# Apache2 install

apt-get install apache2 -y

# Apache2 configuration

hostnamectl set-hostname mail.$domain

cp -f 000-default.conf /etc/apache2/sites-available/000-default.conf
sed -i "s/example.com/$domain/g" /etc/apache2/sites-available/000-default.conf

mkdir /var/www/mail.$domain
chown www-data:www-data /var/www/mail.$domain -R

systemctl reload apache2

# SSL Certificate

apt-get install software-properties-common -y
add-apt-repository ppa:certbot/certbot -y

apt-get update -y

apt-get install certbot -y
apt-get install python3-certbot-apache -y

certbot --apache --non-interactive --agree-tos --redirect --hsts --staple-ocsp -m $username@$domain -d mail.$domain

# Postfix install

apt-get install debconf -y
debconf-set-selections <<< "postfix postfix/mailname string $domain"
debconf-set-selections <<< "postfix postfix/main_mailer_type string 'Internet Site'"
apt-get install postfix -y
apt-get install postfix-policyd-spf-python -y
apt-get install postfix-pcre -y

# Postfix configuration

mkdir /usr/local/etc/postfix
cp -f master.cf /etc/postfix/master.cf
cp -f main.cf /etc/postfix/main.cf
cp -f header_checks /etc/postfix/header_checks
sed -i "s/example.com/$domain/g" /etc/postfix/main.cf

systemctl reload postfix

# Dovecot install

apt-get install dovecot-core dovecot-imapd dovecot-pop3d -y

# Dovecot configuration

cp -f dovecot.conf /etc/dovecot/dovecot.conf
cp -f 10-mail.conf /etc/dovecot/conf.d/10-mail.conf
cp -f 10-auth.conf /etc/dovecot/conf.d/10-auth.conf
cp -f 10-ssl.conf /etc/dovecot/conf.d/10-ssl.conf

sed -i "s/example.com/$domain/g" /etc/dovecot/conf.d/10-ssl.conf

cp -f 10-master.conf /etc/dovecot/conf.d/10-master.conf
cp -f 15-mailboxes.conf /etc/dovecot/conf.d/15-mailboxes.conf

adduser dovecot mail
systemctl restart dovecot
systemctl restart postfix

# OpenDKIM install

apt-get install opendkim opendkim-tools -y

# OpenDKIM configuration

gpasswd -a postfix opendkim

cp -f opendkim.conf /etc/opendkim.conf

mkdir /etc/opendkim
chown -R opendkim:opendkim /etc/opendkim

mkdir /etc/opendkim/keys
chmod go-rw /etc/opendkim/keys

cp -f signing.table /etc/opendkim/signing.table
sed -i "s/example.com/$domain/g" /etc/opendkim/signing.table

cp -f key.table /etc/opendkim/key.table
sed -i "s/example.com/$domain/g" /etc/opendkim/key.table

cp -f trusted.hosts /etc/opendkim/trusted.hosts
sed -i "s/example.com/$domain/g" /etc/opendkim/trusted.hosts

mkdir /etc/opendkim/keys/$domain
opendkim-genkey -b 2048 -d $domain -D /etc/opendkim/keys/$domain -s default -v
chown opendkim:opendkim /etc/opendkim/keys/$domain/default.private

mkdir /var/spool/postfix/opendkim
chown opendkim:postfix /var/spool/postfix/opendkim

cp -f opendkim /etc/default/opendkim

systemctl restart opendkim
systemctl restart postfix

# Adding user with passwd to access smtp, imap and pop3 and block ssh for new user and restart deamon

useradd -m -p $(openssl passwd -1 $password) $username
echo "DenyUsers $username" >> /etc/ssh/sshd_config
service ssh restart

echo 
echo "[SMTP configuration]"
echo 
echo "Host : mail.$domain"
echo "Port : 465"
echo "Protocol : STARTTLS"
echo 
echo "[IMAP configuration]"
echo 
echo "Host : mail.$domain"
echo "Port : 993"
echo "Protocol : STARTTLS"
echo 
echo "[POP3 configuration]"
echo 
echo "Host : mail.$domain"
echo "Port : 110"
echo "Protocol : STARTTLS"
echo 
echo "[Authentication]"
echo 
echo "Username : $username@$domain"
echo "Password : $password"
echo 
echo "[$domain DNS]"
echo 
echo "╔══════╦════════════════════╦═════════════════════════════════════════════"
echo "║ TYPE ║ HOST               ║ VALUE"
echo "╠══════╬════════════════════╬═════════════════════════════════════════════"
echo "║ MX   ║ @                  ║ mail.$domain"
echo "║ A    ║ mail               ║ $(wget -qO- api.ipify.org/?format=text)"
echo "║ AAAA ║ mail               ║ $(wget -qO- api6.ipify.org/?format=text)"
echo "║ TXT  ║ @                  ║ v=spf1 mx ~all"
echo "║ TXT  ║ _dmarc             ║ v=DMARC1; p=none"
echo "║ TXT  ║ default._domainkey ║ $(cat /etc/opendkim/keys/$domain/default.txt | cut -d "(" -f 2 | cut -d ")" -f 1 | sed -e 's/^[[:space:]]*//' | tr -d '\n' | tr -d '"')"

exit